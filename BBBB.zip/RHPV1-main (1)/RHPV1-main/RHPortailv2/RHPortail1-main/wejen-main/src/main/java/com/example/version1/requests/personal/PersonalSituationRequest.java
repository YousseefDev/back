package com.example.version1.requests.personal;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "personal_situation_requests")
public class PersonalSituationRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_full_name")
    private String userFullName;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "title")
    private String title;

    @Column(name = "details")
    private String details;

    @Column(name = "request_type")
    private String requestType; // Personal details modification, Add certificate, Change job tasks, etc.

    @Column(name = "status", columnDefinition = "VARCHAR(255) DEFAULT 'pending'") // Set default status to 'pending'
    private String status;

    @Column (name="response")
    private String response = "Request still under revi" +
            "ew";
}
