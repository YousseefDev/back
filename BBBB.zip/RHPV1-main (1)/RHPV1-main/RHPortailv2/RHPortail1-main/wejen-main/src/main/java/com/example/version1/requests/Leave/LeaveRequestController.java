package com.example.version1.requests.Leave;

import com.example.version1.users.User;
import com.example.version1.users.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import javax.naming.AuthenticationException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/requests/leave")
public class LeaveRequestController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private LeaveRequestService leaveRequestService;

    @GetMapping("/my-leave-requests")
    public ResponseEntity<List<LeaveRequest>> getMyLeaveRequests(Authentication authentication) throws AuthenticationException {
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new AuthenticationException("User not authenticated");
        }

        Jwt jwtToken = (Jwt) authentication.getPrincipal();
        String userEmail = jwtToken.getClaim("sub");

        Optional<User> userOptional = userRepository.findByEmail(userEmail);
        if (userOptional.isEmpty()) {
            throw new AuthenticationException("User not found");
        }
        User user = userOptional.get();

        Long userId = user.getId();

        List<LeaveRequest> userLeaveRequests = leaveRequestService.getLeaveRequestsByUserId(userId);

        return new ResponseEntity<>(userLeaveRequests, HttpStatus.OK);
    }

    @PostMapping("/send-req")
    public ResponseEntity<LeaveRequest> createLeaveRequest(@RequestBody LeaveRequest request,
                                                           Authentication authentication) throws AuthenticationException {
        if (authentication == null || !authentication.isAuthenticated() || !(authentication.getPrincipal() instanceof Jwt)) {
            throw new AuthenticationException("Authentication is missing or invalid for this request");
        }

        Jwt jwtToken = (Jwt) authentication.getPrincipal();
        String userEmail = jwtToken.getClaim("sub");

        Optional<User> userOptional = userRepository.findByEmail(userEmail);
        if (userOptional.isEmpty()) {
            throw new AuthenticationException("User not found");
        }
        User user = userOptional.get();
        Long userId = user.getId();

        request.setUserId(userId);
        request.setUserFullName(user.getFullName());  // Set the user's full name

        LeaveRequest createdRequest = leaveRequestService.createLeaveRequest(request, userId);
        return new ResponseEntity<>(createdRequest, HttpStatus.CREATED);
    }

    @GetMapping("/hr-approved")
    public ResponseEntity<List<LeaveRequest>> getHRApprovedRequestsPendingAdmin() {
        List<LeaveRequest> requests = leaveRequestService.getHRApprovedRequestsPendingAdmin();
        return new ResponseEntity<>(requests, HttpStatus.OK);
    }


    @PutMapping("/{id}/deny-hr")
    public ResponseEntity<LeaveRequest> denyLeaveRequestByHR(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {
        String response = body.get("response");
        LeaveRequest updatedRequest = leaveRequestService.denyByHR(id, response);
        return new ResponseEntity<>(updatedRequest, HttpStatus.OK);
    }

    @PutMapping("/{id}/approve-hr")
    public ResponseEntity<LeaveRequest> approveLeaveRequestByHR(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {
        String response = body.get("response");
        LeaveRequest updatedRequest = leaveRequestService.approveByHR(id, response);
        return new ResponseEntity<>(updatedRequest, HttpStatus.OK);
    }

    @PutMapping("/{id}/approve-admin")
    public ResponseEntity<LeaveRequest> approveOrDenyLeaveRequestByAdmin(@PathVariable Long id,
                                                                         @RequestParam boolean isApproved,
                                                                         @RequestParam(required = false) String response) {
        LeaveRequest updatedRequest = leaveRequestService.approveOrDenyByAdmin(id, isApproved, response);
        return new ResponseEntity<>(updatedRequest, HttpStatus.OK);
    }

    private void validateAuthentication(Authentication authentication) throws AuthenticationException {
        if (authentication == null || !authentication.isAuthenticated() || !(authentication.getPrincipal() instanceof Jwt)) {
            throw new AuthenticationException("User not authenticated");
        }
    }
}
