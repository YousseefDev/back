package com.example.version1.requests.personal;

import com.example.version1.requests.Request;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PersonalSituationRequestRepository extends JpaRepository<PersonalSituationRequest, Long> {
    List<PersonalSituationRequest> findByUserId(Long userId);
    List<PersonalSituationRequest> findByStatus(String status);

    int countByStatus(String status);

}
