package com.example.version1.requests.personal;

import com.example.version1.requests.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonalSituationRequestService {

    @Autowired
    private PersonalSituationRequestRepository personalSituationRequestRepository;

    public PersonalSituationRequest createPersonalSituationRequest(PersonalSituationRequest request, Long userId) {
       return personalSituationRequestRepository.save(request);
    }
    public List<PersonalSituationRequest> getAllPersonalSituationRequests() {
        return personalSituationRequestRepository.findAll();
    }
    public List<PersonalSituationRequest> getPendingPersonalSituationRequests() {
        return personalSituationRequestRepository.findByStatus("pending");
    }
    public PersonalSituationRequest updatePersonalSituationRequestStatusAndResponse(Long id, String newStatus, String response) {
        PersonalSituationRequest request = personalSituationRequestRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Personal situation request not found with ID: " + id));

        request.setStatus(newStatus);
        request.setResponse(response);

        return personalSituationRequestRepository.save(request);
    }
    public List<PersonalSituationRequest> getPersonalSituationRequestsByUserId(Long userId) {
        return personalSituationRequestRepository.findByUserId(userId);
    }


    public int countPendingPersonalSituationRequests() {
        return personalSituationRequestRepository.countByStatus("pending");

    }
}
